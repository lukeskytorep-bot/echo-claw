# ECHO-4 0.4.0-rc.3 — independent GPT-6.2 audit reproductions

Source ZIP SHA-256: `96b6a2fee6671500701cd0f3fb481c6f4e7374f1d03bd7cc972291612cabc1ea`.

Copy these three `.mjs` files to the root of a disposable unpacked copy of the source ZIP. Run from that directory with Node.js 22.16.0 or a compatible Node version:

```sh
node audit-extra.mjs
node audit-extra-smoke.mjs
node audit-extra-crash.mjs
```

These are diagnostic reproductions, not tests that assert the repaired behavior. They use temporary directories and fake CLI commands; no real provider requests or Gateway are used. The smoke test deliberately builds a minimal synthetic SQLite fixture to test the evidence checker, not to claim that Session Core would produce those records. The crash script deliberately kills its own dedicated installer subprocess with SIGKILL after a fake plugin installation. Run on Linux, in a disposable copy. Do not run against a production profile. No project source changes are included.

Expected observations on the original RC3: A1 failed CLI read is treated as absence, A2 failed unset reports rollback success, A3 rollback removes later user changes, A4 backup names collide, A5 diagnostics falsely pass registration, A6 an invalid smoke fixture passes, A7 interrupted installation leaves the plugin installed after rollback reports success.
