import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import {spawnSync} from 'node:child_process';
import {install,buildPlan,rollbackTransaction} from './installer/echo4-install.mjs'; import {assertRuntimeRegistration} from './installer/host-ops.mjs';
const fake=path.resolve('tests/fixtures/fake-openclaw.mjs');
function setup(initial={}){let d=fs.mkdtempSync(path.join(os.tmpdir(),'e4extra-'));let f=path.join(d,'state.json');fs.writeFileSync(f,JSON.stringify({version:'2026.11.7',config:{},installed:false,commands:[],...initial}));process.env.FAKE_OPENCLAW_STATE=f;return {d,f,opts:{command:fake,acceptCapabilities:true,nodeVersion:'24.22.1',monitorWorkspace:path.join(d,'m'),viewerWorkspace:path.join(d,'v'),dataDir:path.join(d,'data'),transactionRoot:path.join(d,'tx')}}}
function st(f){return JSON.parse(fs.readFileSync(f,'utf8'))}
{
let {f,opts}=setup({installed:true});process.env.FAKE_FAIL_ON='plugins list';let p=buildPlan(opts);console.log('A1 list failure:',p.ok,p.pluginInstalled);delete process.env.FAKE_FAIL_ON;
}
{
let {f,opts}=setup({config:{agents:{entries:{main:{tools:{allow:['read']}}}}}});process.env.FAKE_FAIL_ON='config get agents.entries.main.tools';let r=install(opts);delete process.env.FAKE_FAIL_ON;let rb=rollbackTransaction({command:fake,transactionDir:r.transactionDir});console.log('A1 read failure:',JSON.stringify({install:r.ok,rollback:rb.ok,main:st(f).config.agents.entries.main}));
}
{
let {f,opts}=setup();let r=install(opts);process.env.FAKE_FAIL_ON='config unset agents.entries.echo-monitor';let rb=rollbackTransaction({command:fake,transactionDir:r.transactionDir});delete process.env.FAKE_FAIL_ON;console.log('A2 unset failure:',JSON.stringify({rollback:rb.ok,errors:rb.errors,monitor:st(f).config.agents.entries['echo-monitor']}));
}
{
let {d,f,opts}=setup();let r=install(opts);fs.writeFileSync(path.join(d,'m','AGENTS.md'),'USER EDIT AFTER INSTALL');let s=st(f);s.config.agents.entries.main.tools.alsoAllow.push('other_new_tool');fs.writeFileSync(f,JSON.stringify(s));let rb=rollbackTransaction({command:fake,transactionDir:r.transactionDir});console.log('A3 rollback postinstall edits:',JSON.stringify({rollback:rb.ok,userFileExists:fs.existsSync(path.join(d,'m','AGENTS.md')),main:st(f).config.agents.entries.main}));
}
{
let {d,f,opts}=setup();let m=path.join(d,'a','same'),v=path.join(d,'b','same');for (let [dir,txt] of [[m,'MONITOR ORIGINAL'],[v,'VIEWER ORIGINAL']]){fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'AGENTS.md'),txt)}let r=install({...opts,monitorWorkspace:m,viewerWorkspace:v,forceConflicts:true});let rb=rollbackTransaction({command:fake,transactionDir:r.transactionDir});console.log('A4 backup basename collision:',JSON.stringify({rollback:rb.ok,m:fs.readFileSync(path.join(m,'AGENTS.md'),'utf8'),v:fs.readFileSync(path.join(v,'AGENTS.md'),'utf8')}));
}
console.log('A5 registration false positive:',assertRuntimeRegistration({status:'failed',diagnostics:['Missing echo_owner_session echo_monitor_session before_model_request model_call_started model_call_ended']}));
